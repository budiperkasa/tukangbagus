	<div class="home3">    
		<div class="row">
                  
			   
			    <?php if ($this->countModules('home3-sidebar-1')) : ?>
					<div class="home3-sidebar-1 span12">
						<jdoc:include type="modules" name="home3-sidebar-1" style="xhtml" />	
					</div>
				<?php endif; ?>
		</div>
   </div>