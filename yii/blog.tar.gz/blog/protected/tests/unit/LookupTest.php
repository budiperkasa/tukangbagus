<?php

class LookupTest extends CDbTestCase
{
	public $fixtures=array(
		'lookups'=>'Lookup',
	);

	public function testCreate()
	{

	}
}